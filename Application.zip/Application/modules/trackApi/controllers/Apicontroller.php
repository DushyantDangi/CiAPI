<?php

defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . 'libraries/REST_Controller.php';
require APPPATH . 'libraries/Format.php';

class Apicontroller extends REST_Controller {

    function __construct()
    {
        // Construct the parent class
        parent::__construct();

        $this->load->model('Getdata_model', 'dataapi');
        $this->post = $_REQUEST;
        $this->load->library('form_validation');
        $this->load->library('encrypt');
        $this->load->library('session');
        
    }

    function ckeckchwccisno_get(){
       $massage = array(
           'name' => 'testing',
           'city' => 'textcity',
       );
       
       print_r($massage);
    }
    
   public function showdetail_post() {

        $params = json_decode(file_get_contents('php://input'), true);
        if (!empty($params)) {
            $name = $params['name'];
            if ($name) {

                $result = $this->getallditail($name);

                if (!empty($result)) {
                    
                    $array = array(
                        'name' => $result->name,
                        'email' => $result->email,
                        'add' => $result->add,
                        'mob' => $result->mob,
                       
                    );
                    
                    $response = array('status' => '1', 'message' => ResponseMessages::getStatusCodeMessage(200), 'result' => $array);
                } else {
                    $response = array('status' => '0', 'message' => ResponseMessages::getStatusCodeMessage(109));
                }

                echo json_encode($response);
            }
        }
    }
	
	public function getallditail($name = "") {

       
        $this->db->select($this->user . '.*');
       
        $this->db->from($this->user);
        
       

        $this->db->where($this->user . '.status = 1');
        $this->db->where($this->user . '.delete = 0');
		
		  if ($name != "") {
            $this->db->where($this->user . '.name', $name);
        }
       
        $query = $this->db->get();

        $result = $query->result();

        if ($result) {

            if ($name) {
                $result = $query->row();
            } else {
                $result = $query->result();
            }
            return $result;
        } else {
            return FALSE;
        }
    }

	
}
