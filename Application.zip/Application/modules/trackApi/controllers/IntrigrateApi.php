<?php

class checkApi extends CI_Controller {
 
    function __construct() {
        parent::__construct();
        
        // phpinfo();die;
        
        // $ip = $_SERVER['SERVER_ADDR'];
        
        // print_r($ip);die;
        
        
    }
    
    public function index(){}
    
    function checkissueApi() {

       $nonencryteddata = array(
            "key1" => "value1",
			"key2" => "value2",
            "key3" => "value3",
            "key4" => "value4",
          
        );
     
        $nonencryteddatajson = json_encode($nonencryteddata);

        $encryptdata = $this->convertencrypteddata($nonencryteddatajson); //convert in encrypted data...
        
        
        $requestjsonn = array(
                'GetDetailsRequest' => $encryptdata
            );
            
    

        $url = 'user Api url like www.test.com';

        $issueApi = $this->axispostCURL($url, json_encode($requestjsonn));


        print_r($issueApi);
        die;
    }
    
    public function convertencrypteddata($datat) {

        $keyString = "provide key foe encryption data";

        $data = json_encode($datat);

        $key = hex2bin($keyString);

        $iv_size = mcrypt_get_iv_size(MCRYPT_RIJNDAEL_128, MCRYPT_MODE_CBC);
        $iv = mcrypt_create_iv($iv_size, MCRYPT_RAND);
        $blocksize = 16;
        $pad = $blocksize - (strlen($data) % $blocksize);
        $data = $data . str_repeat(chr($pad), $pad);
        $return = base64_encode($iv . mcrypt_encrypt(MCRYPT_RIJNDAEL_128, $key, $data, MCRYPT_MODE_CBC, $iv));

        return $return;
    }

    public function convertdecrypteddata($data) {

     $keyString = "provide key foe encryption data";



        $key = hex2bin($keyString);

        $ciphertext_dec = base64_decode($data);
        $iv_size = mcrypt_get_iv_size(MCRYPT_RIJNDAEL_128, MCRYPT_MODE_CBC);
        echo "IV SIZE IS  :: " . $iv_size . "<br/><br/>";
        $iv_dec = substr($ciphertext_dec, 0, $iv_size);
        $ciphertext_dec = substr($ciphertext_dec, $iv_size);
        $result = mcrypt_decrypt(MCRYPT_RIJNDAEL_128, $key, $ciphertext_dec, MCRYPT_MODE_CBC, $iv_dec);

        return $result;
    }

    public function axispostCURL($_url, $_param) {
       
        
        $ch = curl_init();
       
        curl_setopt($ch, CURLOPT_URL, $_url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($ch, CURLOPT_HEADER, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $_param); 
        
        
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'headerparameter1:headerparameter1',
            'headerparameter2:headerparameter2',
            'Content-Type: application/json'
        ));

        
        curl_setopt($ch, CURLOPT_SSLCERT,"PEM");
        
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, false);
        
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
        
        $pem = '/home/domanename/ssl/certs/certificate.pem';
        
        curl_setopt($ch, CURLOPT_SSLCERT, $pem);
      
        $output = curl_exec($ch);
        
        if (curl_errno($ch)) {
            print "Error: " . curl_error($ch);
        } else {

            curl_close($ch);

            return $output;
        }
    }
    
}