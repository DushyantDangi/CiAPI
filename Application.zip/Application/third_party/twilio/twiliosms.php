<?php

class Twiliosms
{
     function __construct()
     {
          //parent::__construct();
          
          require_once(APPPATH . 'third_party/twilio/Services/Twilio.php');

          $this->accsid			=	"ACb6e8b726da93630a30e52f5fbc8a6058";       //Base URL for SMS to send
		$this->auth_token		=	"3de1fc996f90c36aed97490fa96eec47";       //SMS Username
          $this->from              =    "+12138354009";
          $this->to                =    "";
          $this->body              =    "";
          
          $this->client            =    new Services_Twilio($this->accsid, $this->auth_token);
     }
     
     public function send($to, $message)
     {
          if($to != "" && $message != "")
          {
               $this->to      =    $to;
               $this->body    =    strip_tags($message);
               $response      =    $this->client->account->messages->create(array('From' => $this->from, 'To' => $this->to, 'Body' => $this->body));
               print_r($response);
               $result        =    json_decode($response);
               if(!empty($result))
                    return $result;
               else
                    return FALSE;
          }
          else
               return FALSE;
     }
}